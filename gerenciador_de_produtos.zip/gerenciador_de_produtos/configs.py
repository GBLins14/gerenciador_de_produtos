
username = 'admin'  # Usuario e senha, para logar no painel admin.
password = b'$2b$12$buzsN0Bg1Whu7g52HrsEMO1QhDbKUcHSFhTOkL22u1z5MKvhFIPIO'  # Gere sua Hash em (a.py)

database_products = 'mongodb://localhost:27017/'  # Sua database. MongoDB

plans = ['Admin', 'Member']  # OBS: Não retirar o 'Admin'.